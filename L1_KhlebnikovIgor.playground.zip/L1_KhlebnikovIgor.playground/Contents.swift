import UIKit

//task 1 quadratic equation
//ax^2 + bx + c = 0
let a:Double = 3
let b:Double = -14
let c:Double = -5
var X1:Double? = nil
var X2:Double? = nil

print("task 1 quadratic equation")
let D:Double = pow(b,2)  - 4 * a * c

if D == 0 {
    X1 = -b/(2 * a)
    print("The equation has one root: \(X1!)")}
else if D > 0 {
    X1 = (-b + sqrt(D))/(2 * a)
    X2 = (-b - sqrt(D))/(2 * a)
    print("The equation has two roots: \(X1!) and \(X2!)")
} else {
    print("Equation has no solution")
}


//task 2 triangle
print("\ntask 2 right triangle")
let a1:Double = 3 //right triangle leg
let b1:Double = 5 //right triangle leg
let c1:Double? = sqrt(pow(a1,2) + pow(b1,2))
print("right triangle hypotenuse: \(c1!)")

let l:Double? = a1 + b1 + c1!
print("perimeter triangle: \(l!)")

let s:Double? = (a1 * b1)/2
print("area of a right triangle: \(s!)")

//task 3 triangle
print("\ntask 3 найти сумму вклада")
let P:Double = 100000//первоначальная сумма денежных средств
let I:Double = 12//годовая процентная ставка
let K:Double = 365//количество дней в календарном году
let j:Double = 30//начисление процентов каждый месяц (30 дней)
let Y:Double = 5//срок хранения вклада (в годах)

let S = P * pow((1 + I*j/(100*K)),Y*K/j)

print(String(format: "Общая сумма вклада через %.0f лет будет равна %.2f денежных единиц",Y,S))
